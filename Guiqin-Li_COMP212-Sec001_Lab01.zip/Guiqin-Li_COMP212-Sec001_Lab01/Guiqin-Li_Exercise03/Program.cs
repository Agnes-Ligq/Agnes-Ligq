﻿using System;
//using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinkedListLibrary;
using QueueInheritanceLibrary;


namespace Guiqin_Li_Exercise03
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //Test LinkedListLibrary
            Console.WriteLine("LinkedListLibrary test starts: \n");
            LinkedListLibrary.List<int> list = new LinkedListLibrary.List<int>(); // create List container
            List<double> listDouble = new List<double>();


            //create data to store in List
            int anInteger = 34567;
            int anInteger2 = 567;
            int anInteger3 = 345;
            int anInteger4 = 67;

             // use List insert methods

            list.InsertAtFront(anInteger);
            //list.Display();
            list.InsertAtFront(anInteger2);
            //list.Display();
            list.InsertAtBack(anInteger3);
            //list.Display();
            list.InsertAtBack(anInteger4);
            list.Display();

            //call minimum method
            Console.WriteLine("The minimal integer number is:");
            int min = list.Minimum();
            Console.WriteLine(min);

            // find the last value in the list
            Console.WriteLine("\nThe last number in the integer list is:");
            int last = list.GetLastNode();
            Console.WriteLine(last);
                Console.WriteLine();



            double aDouble1 = 34567.45;
            double aDouble2 = 567.23;
            double aDouble3 = 345.78;
            double aDouble4 = 67.89;
         

            // ...double values added to the linkedList -listDouble

            listDouble.InsertAtFront(aDouble1);
           // listDouble.Display();
            listDouble.InsertAtFront(aDouble2);
           // listDouble.Display();
            listDouble.InsertAtBack(aDouble3);
            //listDouble.Display();
            listDouble.InsertAtBack(aDouble4);
            listDouble.Display();

            //call minimum method
            Console.WriteLine("The minimal double number is:");
            double minu = listDouble.Minimum();
            Console.WriteLine(minu);

            // find the last value in the list
            Console.WriteLine("\nThe last number in the double list is:");
            double lastDouble = listDouble.GetLastNode();
            Console.WriteLine(lastDouble);
                Console.WriteLine();





            //Test QueueInheritanceLibrary
            Console.WriteLine("\nQueueInheritanceLibrary test starts\n");
            QueueInheritance<int> queue = new QueueInheritance<int>();
            QueueInheritance<double> queue1 = new QueueInheritance<double>();

            //use method Enqueue to add integer to queue
            Console.WriteLine("This is an integer queue:");
            queue.Enqueue(123);
           // queue.Display();
            queue.Enqueue(456);
           // queue.Display();
            queue.Enqueue(789);
           // queue.Display();
            queue.Enqueue(567);
            queue.Display();

            //find the last number in a queue
            Console.Write("\nThe last number in the queue is: ");
            Console.Write(queue.GetLast());
            Console.WriteLine();

           // use method Enqueue to add double to queue
            Console.WriteLine("\nThis is an double queue:");
            queue1.Enqueue(123.45);
           // queue1.Display();
            queue1.Enqueue(345.89);
           // queue1.Display();
            queue1.Enqueue(12.23);
           // queue1.Display();
            queue1.Enqueue(1234.11);
            queue1.Display();


            Console.Write("\nThe last number in the queue is: ");
            Console.WriteLine(queue1.GetLast());
            Console.WriteLine();





            //remove data from list and display after each removal
            //try
            //{
            //    int removedObject = list.RemoveFromFront();
            //    Console.WriteLine($"{removedObject} removed");
            //    list.Display();

            //    removedObject = list.RemoveFromFront();
            //    Console.WriteLine($"{removedObject} removed");
            //    list.Display();

            //    removedObject = list.RemoveFromBack();
            //    Console.WriteLine($"{removedObject} removed");
            //    list.Display();

            //    //removedObject = list.RemoveFromBack();
            //    //Console.WriteLine($"{removedObject} removed");
            //    //removedObject = list.RemoveFromBack();
            //    //list.Display();
            //}
            //catch (EmptyListException emptyListException)
            //{
            //    Console.Error.WriteLine($"\n{emptyListException}");
            //} // end catch

            Console.WriteLine($"Demonstration of linked of int type is over");


        }
    }
}
