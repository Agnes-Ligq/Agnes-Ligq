﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guiqin_Li_Exercise01
{
    internal class Program
    {
        static void Main(string[] args)           
        {
            Random rnd = new Random();

            //create an int array
            int[] arrayInt = new int[10];
            int searchKey1 = 22;
            Console.WriteLine("The integer list is:");
            for (int i = 0; i < arrayInt.Length; i++)
            {
                arrayInt[i] = rnd.Next(10, 49);
                Console.Write($" {arrayInt[i]} ");
            }


            //create a string array
            string[] arrayString = {"ab","abc","ef","1c","de","ah","mn","hello","blue","yello" };
            string searchKey2 = "abc";

            //create a double array
            Console.WriteLine("\nThe double list is:");
            double[] arrayDouble = new double[10];
            for (int i = 0; i < arrayDouble.Length; i++)
            {
              
                arrayDouble[i] = Math.Round(rnd.NextDouble()*(99-55)+55,2);
                Console.Write($" {arrayDouble[i]} ");
            }
            Console.WriteLine();

            //Create a char array
            Console.WriteLine("\nThe char list is");
            char[] arrayChar=new char[10];
            for(int i = 0;i < arrayChar.Length; i++)
            {
                arrayChar[i] = (char)rnd.Next('a', 'z');
                Console.Write($" {arrayChar[i]} ");
            }



            //test int array, call the search method
            int position1 = Search<int>(arrayInt, searchKey1);
            //print the search result
            if (position1 == -1)
            {
                Console.WriteLine("\n\nNo data found");
            }
            else
            {
                Console.WriteLine($"\nThe value {searchKey1} in array's position is {position1}");
            }

            //test string array, call the search method
            int position2 = Search<string>(arrayString, searchKey2);
            //print the search result
            if (position2==-1)
            {
                Console.WriteLine("\nNo data found");
            }
            else
            {
                Console.WriteLine($"\nThe value {searchKey2} in array's position is {position2}");
            }



        }

        //Generic method for search a value
        public static int Search<T>(T[] dataArray, T searchKey) where T: IComparable<T>
        {
            
            for(int i=0; i<dataArray.Length; i++)
            {
                if (dataArray[i].CompareTo(searchKey)==0)
                {
                    return i;
                }
            }


            return -1;
        }
    }
}
