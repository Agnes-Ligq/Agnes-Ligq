﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Guiqin_Li_Exercise02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringBuilder str1 = new StringBuilder("This is to test whether the extension method count can return a right answer or not");
            StringBuilder str2 =new StringBuilder( "You can define extension methods for user defined types as well as predefined types");
            
            //call the extension method
            
            Console.WriteLine($"The number of words in the sentence are:"+str1.CountWords());
            Console.WriteLine($"\nThe number of words in the sentence are:" + str2.CountWords());

        }



    }

     
}
