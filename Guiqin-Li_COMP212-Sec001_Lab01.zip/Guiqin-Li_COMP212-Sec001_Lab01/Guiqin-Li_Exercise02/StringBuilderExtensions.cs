﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Guiqin_Li_Exercise02
{
    public static class StringBuilderExtensions
    {
        // extention method to count number of words
        public static int CountWords(this StringBuilder value)
        {
            string[] words = value.ToString().Split(' ');
            return words.Length;
        }

    }
}
