﻿using System;
using LinkedListLibrary;


namespace QueueInheritanceLibrary
{
    public class QueueInheritance<T> : List<T> where T : IComparable<T>
    {
       

        public void Enqueue(T value)
        {
            InsertAtBack(value);
        }

        public T GetLast()
        {

            return GetLastNode();
        }


    }
}